-- Written by Claude Code, edited by siddiqui MacCormick

-- Create the database (run this as postgres superuser)
-- You may need to disconnect from the sqldemo database first if it exists
DROP DATABASE IF EXISTS sqldemo;
CREATE DATABASE sqldemo;

-- Connect to the sqldemo database and run the following:
\c sqldemo

-- Create users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    role VARCHAR(20)
);

-- Insert sample data
INSERT INTO users (username, password, email, role) VALUES
    ('admin', 'admin123', 'admin@example.com', 'administrator'),
    ('user', 'user123', 'user@example.com', 'user'),
    ('siddiqui', 'siddiqui456', 'siddiqui@example.com', 'user'),
    ('ferland', 'ferland789', 'ferland@example.com', 'user');

-- Display the created data
SELECT * FROM users;
