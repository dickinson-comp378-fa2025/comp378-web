<!-- Written by Claude Code, edited by John MacCormick -->


# SQL Injection Demo

This is a simple, intentionally vulnerable web application designed to demonstrate SQL injection attacks for educational purposes.

**⚠️ WARNING: This application contains serious security vulnerabilities. NEVER use this code in production or expose it to the internet!**

## Prerequisites

- PostgreSQL installed and running
- Node.js installed (version 12 or higher)

## Setup Instructions

### 1. Set up the PostgreSQL Database

Open your PostgreSQL command line (psql) and run the setup script:

```bash
psql -U postgres -f setup.sql
```

Or manually:
1. Connect to PostgreSQL: `psql -U postgres`
2. Run the commands in `setup.sql`

The script will:
- Create a database called `sqldemo`
- Create a `users` table
- Insert sample user data

### 2. Update Database Credentials (if needed)

If your PostgreSQL credentials differ from the defaults, edit `server.js` and update:

```javascript
const pool = new Pool({
  user: 'postgres',      // Your PostgreSQL username
  host: 'localhost',
  database: 'sqldemo',
  password: 'postgres',  // Your PostgreSQL password
  port: 5432,
});
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Start the Server

```bash
npm start
```

The server will start at `http://localhost:3000`

## How to Use

1. Open your browser and navigate to `http://localhost:3000`
2. Try the examples provided on the page

### Valid Login Credentials

- Username: `admin`, Password: `admin123`
- Username: `user`, Password: `user123`

### SQL Injection Examples

**Example 1: OR-based injection**
- Username: `admin' OR '1'='1`
- Password: `anything`

This creates the query:
```sql
SELECT * FROM users WHERE username = 'admin' OR '1'='1' AND password = 'anything'
```
Since `'1'='1'` is always true, this bypasses authentication.

**Example 2: Comment-based injection**
- Username: `admin' --`
- Password: `anything`

This creates the query:
```sql
SELECT * FROM users WHERE username = 'admin' -- ' AND password = 'anything'
```
The `--` comments out the rest of the query, ignoring the password check.

**Example 3: Simple OR injection**
- Username: `' OR 1=1 --`
- Password: `anything`

This creates the query:
```sql
SELECT * FROM users WHERE username = '' OR 1=1 -- ' AND password = 'anything'
```
This returns all users since `1=1` is always true.

## What Makes This Vulnerable?

In `server.js`, the login endpoint builds SQL queries using string concatenation:

```javascript
const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
```

This allows attackers to inject their own SQL code through the input fields.

## The Secure Way

To prevent SQL injection, use **parameterized queries**:

```javascript
// SECURE VERSION
const query = 'SELECT * FROM users WHERE username = $1 AND password = $2';
const result = await pool.query(query, [username, password]);
```

With parameterized queries, user input is treated as data, not executable SQL code.

## Teaching Points

1. **Never trust user input** - All user input should be treated as potentially malicious
2. **Use parameterized queries** - This is the primary defense against SQL injection
3. **Principle of least privilege** - Database users should have minimal necessary permissions
4. **Input validation** - While not a complete solution, validating input adds defense in depth
5. **Error handling** - Don't expose detailed error messages that reveal database structure

## Files

- `server.js` - Vulnerable Express server
- `public/index.html` - Login page with examples
- `setup.sql` - Database setup script
- `package.json` - Node.js dependencies

## Cleanup

To remove the demo database:

```bash
psql -U postgres -c "DROP DATABASE sqldemo;"
```
