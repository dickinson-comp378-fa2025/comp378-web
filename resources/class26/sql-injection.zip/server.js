// Written by Claude Code, edited by John MacCormick


const express = require('express');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const port = 3000;

// PostgreSQL connection pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'sqldemo',
  password: 'tt99ww77',
  port: 5432,
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// VULNERABLE LOGIN ENDPOINT - DO NOT USE IN PRODUCTION
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // THIS IS VULNERABLE! User input is directly concatenated into the SQL query
  const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;

  console.log('Executing query:', query);

  try {
    const result = await pool.query(query);

    if (result.rows.length > 0) {
      res.json({
        success: true,
        message: 'Login successful!',
        user: result.rows[0],
        query: query
      });
    } else {
      res.json({
        success: false,
        message: 'Invalid credentials',
        query: query
      });
    }
  } catch (error) {
    res.json({
      success: false,
      message: 'Error: ' + error.message,
      query: query
    });
  }
});

app.listen(port, () => {
  console.log(`SQL Injection Demo running at http://localhost:${port}`);
  console.log('WARNING: This application is intentionally vulnerable for educational purposes!');
});
